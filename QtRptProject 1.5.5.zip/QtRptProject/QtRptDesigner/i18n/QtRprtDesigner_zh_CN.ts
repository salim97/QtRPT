<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../aboutDlg.cpp" line="27"/>
        <source>About QtRptDesigner</source>
        <translation>关于 QtRptDesine</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="44"/>
        <source>Version: </source>
        <translation>版本: </translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="45"/>
        <source>Programmer: Aleksey Osipov</source>
        <translation>作者: Aleksey Osipov</translation>
    </message>
    <message>
        <source>2012-2014 years</source>
        <translation type="vanished">2012-2014 年</translation>
    </message>
    <message>
        <source>Thanks to:</source>
        <translation type="vanished">致谢:</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="49"/>
        <source>2012-2015 years</source>
        <translation>2012-2015 年</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="50"/>
        <source>Thanks for donation:</source>
        <translation>感谢捐赠：</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="52"/>
        <source>Sailendram</source>
        <translation>Sailendram</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="54"/>
        <source>Thanks for project developing:</source>
        <translation>感谢参与项目：</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="56"/>
        <source>Lukas Lalinsky for DBmodel</source>
        <translation>Lukas Lalinsky 对 DBmodel 的贡献</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="57"/>
        <source>Norbert Schlia for help in developing</source>
        <translation>Norbert Schlia 在开发中提供了帮助</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="58"/>
        <source>Muhamad Bashir Al-Noimi for Arabic translation</source>
        <translation>Muhamad Bashir Al-Noimi 翻译为阿拉伯语</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="59"/>
        <source>Luis Brochado for Portuguese translation</source>
        <translation>Luis Brochado 翻译为葡萄牙语</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="60"/>
        <source>Li Wei for Chinese translation</source>
        <translation>Li Wei 翻译为简体中文</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="61"/>
        <source>Laurent Guilbert for French translation</source>
        <translation>Laurent Guilbert 翻译为法语</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="62"/>
        <source>David Heremans for Dutch translation</source>
        <translation>David Heremans 翻译为荷兰语</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="63"/>
        <source>Mirko Marx for German translation</source>
        <translation>Mirko Marx 翻译为德语</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="64"/>
        <source>Manuel Soriano for Spanish translation</source>
        <translation>Manuel Soriano 翻译为西班牙语</translation>
    </message>
</context>
<context>
    <name>EditFldDlg</name>
    <message>
        <location filename="../EditFldDlg.ui" line="14"/>
        <source>Field editor</source>
        <translation>字段编辑器</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="61"/>
        <location filename="../EditFldDlg.ui" line="176"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="100"/>
        <source>Add variable</source>
        <translation>添加变量</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="103"/>
        <location filename="../EditFldDlg.ui" line="123"/>
        <location filename="../EditFldDlg.ui" line="143"/>
        <location filename="../EditFldDlg.ui" line="466"/>
        <location filename="../EditFldDlg.ui" line="483"/>
        <location filename="../EditFldDlg.ui" line="714"/>
        <location filename="../EditFldDlg.ui" line="728"/>
        <location filename="../EditFldDlg.ui" line="742"/>
        <location filename="../EditFldDlg.ui" line="756"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="120"/>
        <source>Add function</source>
        <translation>添加函数</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="140"/>
        <source>Add formatting</source>
        <translation>添加格式</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="160"/>
        <source>Text direction</source>
        <translation>文本方向</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="163"/>
        <source>&lt;-</source>
        <translation>&lt;-</translation>
    </message>
    <message>
        <source>Proccess as Image</source>
        <translation type="vanished">作为图像处理</translation>
    </message>
    <message>
        <source>Attention! You may enter just ONE varibale and not any text.</source>
        <translation type="vanished">注意! 你输入的仅仅是一个变量而不是文本.</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="227"/>
        <source>Condtion</source>
        <translation>条件</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="235"/>
        <source>Printing</source>
        <translation>打印</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="248"/>
        <source>Hightlighting</source>
        <translation>高亮</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="260"/>
        <source>Condition</source>
        <translation>条件</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="277"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="283"/>
        <source>Bold</source>
        <translation>加粗</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="290"/>
        <source>Italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="297"/>
        <source>Underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="304"/>
        <source>Strikeout</source>
        <translation>删除线</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="339"/>
        <location filename="../EditFldDlg.ui" line="405"/>
        <source>Color...</source>
        <translation>颜色...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="354"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="360"/>
        <source>Transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="370"/>
        <source>Other</source>
        <translation>其它</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="480"/>
        <source>Save As</source>
        <translation>另存为</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="497"/>
        <source>Ignore aspect ratio</source>
        <translation>忽略缩放比例</translation>
    </message>
    <message>
        <source>Diagram&apos;s property</source>
        <translation type="vanished">图表属性</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="599"/>
        <source>Diagram</source>
        <translation>图表</translation>
    </message>
    <message>
        <source>Chart&apos;s caption</source>
        <translation type="vanished">图表标题</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="619"/>
        <source>Show caption</source>
        <translation>显示标题</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="626"/>
        <source>Show grid</source>
        <translation>显示网格</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="633"/>
        <source>Show legend</source>
        <translation>显示图例</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="640"/>
        <source>Set the params of the graphs</source>
        <translation>设置图表参数</translation>
    </message>
    <message>
        <source>Show graph&apos;s caption</source>
        <translation type="vanished">显示图表标题</translation>
    </message>
    <message>
        <source>Graph&apos;s caption</source>
        <translation type="vanished">图表标题</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="663"/>
        <source>Real values</source>
        <translation>实际值</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="673"/>
        <source>Percent values</source>
        <translation>百分数</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="700"/>
        <source>Graphs</source>
        <translation>图表</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="711"/>
        <source>Add row</source>
        <translation>添加行</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="725"/>
        <source>Remove row</source>
        <translation>删除行</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="739"/>
        <source>Up</source>
        <translation>向上</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="753"/>
        <source>Down</source>
        <translation>向下</translation>
    </message>
    <message>
        <source>Новая строка</source>
        <translation type="vanished">换行</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="807"/>
        <source>Caption</source>
        <translation>标题</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="812"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="817"/>
        <source>Color</source>
        <translation>颜色</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="833"/>
        <source>Barcode type</source>
        <translation>条形码类型</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="857"/>
        <source>Frame type</source>
        <translation>边框样式</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="845"/>
        <source>Value:</source>
        <translation>值:</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="183"/>
        <source>Process as image</source>
        <translation>处理为图片</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="190"/>
        <source>Image from database</source>
        <translation>数据库中的图片</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="219"/>
        <source>Attention! You may enter just ONE variable and not any text.</source>
        <translation>注意! 你输入的仅仅是一个变量而不是文本.</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="593"/>
        <source>Diagram property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="607"/>
        <source>Chart caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="647"/>
        <source>Show graph caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="657"/>
        <source>Graph caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="877"/>
        <source>Height</source>
        <translation>高度</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="884"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="935"/>
        <source>Dimensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="941"/>
        <source>Rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="951"/>
        <source>Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="964"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="970"/>
        <source>Show row header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="977"/>
        <source>Show column header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="984"/>
        <source>Show row total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="991"/>
        <source>Show column total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1003"/>
        <source>Row headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1023"/>
        <source>Row header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1035"/>
        <source>Column headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1055"/>
        <source>Column header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1084"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1091"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="234"/>
        <location filename="../EditFldDlg.cpp" line="294"/>
        <source>Empty line</source>
        <translation>空行</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="234"/>
        <location filename="../EditFldDlg.cpp" line="294"/>
        <source>The field contains empty line at the end.
Remove it?</source>
        <translation>字段最后包含一个空行.
是否删除?</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="575"/>
        <source>Save Image As</source>
        <translation>保存图片为</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="577"/>
        <source>Images (*.png)</source>
        <translation>图片 （*.png)</translation>
    </message>
</context>
<context>
    <name>EditorDelegate</name>
    <message>
        <location filename="../mainwindow.cpp" line="52"/>
        <source>Left</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="53"/>
        <location filename="../mainwindow.cpp" line="63"/>
        <source>Center</source>
        <translation>居中对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="54"/>
        <source>Right</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="55"/>
        <source>Justify</source>
        <translation>两端对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="62"/>
        <source>Top</source>
        <translation>顶部对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="64"/>
        <source>Bottom</source>
        <translation>底部对齐</translation>
    </message>
</context>
<context>
    <name>FldPropertyDlg</name>
    <message>
        <location filename="../FldPropertyDlg.ui" line="14"/>
        <source>Expression editor</source>
        <translation>表达式编辑器</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="66"/>
        <source>Data filed grouping</source>
        <translation>数据字段组</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="78"/>
        <source>Start line numeration for each group</source>
        <translation>对每个组使用行计数</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="88"/>
        <source>Start new page for each group</source>
        <translation>每个组重新开一页</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="114"/>
        <source>Category</source>
        <translation>目录</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="121"/>
        <source>Number</source>
        <translation>数字</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="132"/>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="146"/>
        <source>Other</source>
        <translation>其它</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="167"/>
        <source>Precision</source>
        <translation>精度</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="198"/>
        <source>Format string</source>
        <translation>格式化字符串</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="212"/>
        <source>Clear</source>
        <translation>清楚</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="243"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="250"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="54"/>
        <location filename="../FldPropertyDlg.cpp" line="93"/>
        <source>Variables</source>
        <translation>变量</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="55"/>
        <source>System variables</source>
        <translation>系统变量</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="97"/>
        <location filename="../FldPropertyDlg.cpp" line="219"/>
        <source>Functions</source>
        <translation>函数</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="100"/>
        <source>Aggregate functions</source>
        <translation>统计函数</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="135"/>
        <source>Text functions</source>
        <translation>文本函数</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="141"/>
        <source>English</source>
        <translation>英语</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="148"/>
        <source>German</source>
        <translation>德语</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="155"/>
        <source>Ukrainian</source>
        <translation>乌克兰语</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="162"/>
        <source>Spanish</source>
        <translation>西班牙语</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="169"/>
        <source>French</source>
        <translation type="unfinished">法语</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="176"/>
        <source>French(BE)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="183"/>
        <source>French(CH)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="191"/>
        <source>Math functions</source>
        <translation>数学函数</translation>
    </message>
</context>
<context>
    <name>ItemPropertyDlg</name>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="14"/>
        <source>Object property</source>
        <translation>对象属性</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="44"/>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="78"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="105"/>
        <source>Relation property</source>
        <translation>关系属性</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="128"/>
        <source>Parent table</source>
        <translation>父表</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="145"/>
        <source>Columns:</source>
        <translation>列:</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="159"/>
        <source>reference</source>
        <translation>引用</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="166"/>
        <source>Child table</source>
        <translation>子表</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="208"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="215"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>QtRPT Designer</source>
        <translation>QtRPT Designer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <location filename="../mainwindow.cpp" line="2112"/>
        <location filename="../mainwindow.cpp" line="2275"/>
        <source>Name</source>
        <translation>属性名</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="157"/>
        <source>Value</source>
        <translation>属性值</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="195"/>
        <location filename="../mainwindow.cpp" line="307"/>
        <source>Report</source>
        <translation>报表</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="220"/>
        <source>Service</source>
        <translation>服务</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="275"/>
        <source>toolBar</source>
        <translatorcomment>貌似用户是不会显示的无需翻译</translatorcomment>
        <translation>toolBar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="313"/>
        <source>toolBar_2</source>
        <translatorcomment>貌似用户是不会显示的无需翻译</translatorcomment>
        <translation>toolBar_2</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="324"/>
        <source>toolBar_3</source>
        <translatorcomment>貌似用户是不会显示的无需翻译</translatorcomment>
        <translation>toolBar_2</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <location filename="../mainwindow.ui" line="349"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="358"/>
        <source>Page settings</source>
        <translation>页面设置</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="370"/>
        <location filename="../mainwindow.ui" line="373"/>
        <source>Select tool</source>
        <translation>选择工具</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="385"/>
        <location filename="../mainwindow.ui" line="388"/>
        <source>Align left</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="400"/>
        <location filename="../mainwindow.ui" line="403"/>
        <source>Align center</source>
        <translation>居中</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="415"/>
        <location filename="../mainwindow.ui" line="418"/>
        <source>Align right</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="430"/>
        <location filename="../mainwindow.ui" line="433"/>
        <location filename="../mainwindow.cpp" line="2137"/>
        <source>Justify</source>
        <translation>两端对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="445"/>
        <location filename="../mainwindow.ui" line="448"/>
        <location filename="../mainwindow.cpp" line="2297"/>
        <source>Bold</source>
        <translation>加粗</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="460"/>
        <location filename="../mainwindow.ui" line="463"/>
        <location filename="../mainwindow.cpp" line="2307"/>
        <source>Italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="475"/>
        <location filename="../mainwindow.ui" line="478"/>
        <location filename="../mainwindow.cpp" line="2317"/>
        <source>Underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="490"/>
        <location filename="../mainwindow.ui" line="493"/>
        <source>Top line</source>
        <translation>上框线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="505"/>
        <location filename="../mainwindow.ui" line="508"/>
        <source>Bottom line</source>
        <translation>下框线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="520"/>
        <location filename="../mainwindow.ui" line="523"/>
        <source>Left line</source>
        <translation>左框线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="535"/>
        <location filename="../mainwindow.ui" line="538"/>
        <source>Right line</source>
        <translation>右框线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="550"/>
        <location filename="../mainwindow.ui" line="553"/>
        <source>All frame line</source>
        <translation>外框线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="565"/>
        <location filename="../mainwindow.ui" line="568"/>
        <source>No frame</source>
        <translation>无框线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="580"/>
        <location filename="../mainwindow.ui" line="583"/>
        <source>Insert band</source>
        <translatorcomment>暂且这么翻译</translatorcomment>
        <translation>插入区块</translation>
    </message>
    <message>
        <source>Add Filed</source>
        <translation type="vanished">添加字段</translation>
    </message>
    <message>
        <source>Add filed</source>
        <translation type="vanished">添加字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="598"/>
        <source>Add Fleld</source>
        <translation>添加字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="601"/>
        <source>Add field</source>
        <translation>添加字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="610"/>
        <location filename="../mainwindow.ui" line="613"/>
        <source>New report</source>
        <translation>新建报表</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="622"/>
        <location filename="../mainwindow.ui" line="625"/>
        <source>Open report</source>
        <translation>打开报表</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="628"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="640"/>
        <location filename="../mainwindow.ui" line="643"/>
        <source>Save report</source>
        <translation>保存报表</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="646"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <location filename="../mainwindow.ui" line="661"/>
        <source>Align top</source>
        <translation>顶部对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="673"/>
        <location filename="../mainwindow.ui" line="676"/>
        <source>Align V center</source>
        <translation>垂直居中</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="688"/>
        <location filename="../mainwindow.ui" line="691"/>
        <source>Align bottom</source>
        <translation>底部对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="700"/>
        <location filename="../mainwindow.ui" line="703"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="706"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="715"/>
        <location filename="../mainwindow.ui" line="718"/>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="721"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="733"/>
        <location filename="../mainwindow.ui" line="736"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="739"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="748"/>
        <location filename="../mainwindow.ui" line="751"/>
        <source>Save as</source>
        <translation>另存为</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="760"/>
        <location filename="../mainwindow.ui" line="763"/>
        <source>Font color</source>
        <translation>字体颜色</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="772"/>
        <location filename="../mainwindow.ui" line="775"/>
        <source>Background color</source>
        <translation>背景颜色</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.ui" line="787"/>
        <source>Border color</source>
        <translation>边框颜色</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="796"/>
        <source>About QtRptDesigner</source>
        <translation>关于 QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="808"/>
        <source>Show Grid</source>
        <translation>显示网格</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="811"/>
        <source>Show/Hide grid</source>
        <translation>显示/隐藏 网格</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="826"/>
        <source>Add picture</source>
        <translation>添加图片</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="835"/>
        <location filename="../mainwindow.ui" line="838"/>
        <source>Frame style</source>
        <translation>边框样式</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="847"/>
        <location filename="../mainwindow.ui" line="850"/>
        <source>New Report Page</source>
        <translation>新建报表页</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="859"/>
        <location filename="../mainwindow.ui" line="862"/>
        <source>Delete Report Page</source>
        <translation>删除报表页</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="871"/>
        <location filename="../mainwindow.ui" line="874"/>
        <source>Align Field Left</source>
        <translation>左对齐字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="883"/>
        <location filename="../mainwindow.ui" line="886"/>
        <source>Align Field Middle</source>
        <translation>水平居中字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="895"/>
        <location filename="../mainwindow.ui" line="898"/>
        <source>Align Field Right</source>
        <translation>右对齐字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="907"/>
        <location filename="../mainwindow.ui" line="910"/>
        <source>Align Field Top</source>
        <translation>顶部对齐字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="919"/>
        <location filename="../mainwindow.ui" line="922"/>
        <source>Align Field Center</source>
        <translation>垂直居中字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="931"/>
        <location filename="../mainwindow.ui" line="934"/>
        <source>Align Field Bottom</source>
        <translation>底部对齐字段</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="943"/>
        <location filename="../mainwindow.ui" line="946"/>
        <source>Field Same Width</source>
        <translation>字段等宽</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="955"/>
        <location filename="../mainwindow.ui" line="958"/>
        <source>Field Same Height</source>
        <translation>字段等高</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="967"/>
        <location filename="../mainwindow.ui" line="970"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="982"/>
        <location filename="../mainwindow.ui" line="985"/>
        <source>Magnifying glass</source>
        <translation>放大镜</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="997"/>
        <location filename="../mainwindow.ui" line="1000"/>
        <location filename="../mainwindow.cpp" line="2327"/>
        <source>Strikeout</source>
        <translation>删除线</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1009"/>
        <location filename="../mainwindow.ui" line="1012"/>
        <source>Group property</source>
        <translation>组属性</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1021"/>
        <location filename="../mainwindow.ui" line="1024"/>
        <source>Check updates</source>
        <translation>检查更新</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1039"/>
        <location filename="../mainwindow.ui" line="1042"/>
        <source>Add Diagram</source>
        <translation>添加图表</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1057"/>
        <location filename="../mainwindow.ui" line="1060"/>
        <source>Add Drawing</source>
        <translation>插入形状</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1072"/>
        <location filename="../mainwindow.ui" line="1075"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1087"/>
        <location filename="../mainwindow.ui" line="1090"/>
        <source>Data Source</source>
        <translation>数据源</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1102"/>
        <location filename="../mainwindow.ui" line="1105"/>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1108"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1120"/>
        <location filename="../mainwindow.ui" line="1123"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1126"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1141"/>
        <location filename="../mainwindow.ui" line="1144"/>
        <source>Add Barcode</source>
        <translation>添加条形码</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1153"/>
        <location filename="../mainwindow.ui" line="1156"/>
        <source>Readme</source>
        <translation>自述文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1171"/>
        <location filename="../mainwindow.ui" line="1174"/>
        <source>Add Rich Text</source>
        <translation>添加富文本</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1183"/>
        <location filename="../mainwindow.ui" line="1186"/>
        <source>To group</source>
        <translation>分组</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1195"/>
        <location filename="../mainwindow.ui" line="1198"/>
        <source>To ungroup</source>
        <translation>取消组</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1213"/>
        <location filename="../mainwindow.ui" line="1216"/>
        <source>Add CrossTab object</source>
        <translation type="unfinished">添加 CrossTab 对象</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1231"/>
        <location filename="../mainwindow.ui" line="1234"/>
        <source>Add CrossTabBD object</source>
        <translation type="unfinished">添加 CrossTabBD 对象</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="233"/>
        <source>Font name</source>
        <translation>字体名</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Font size</source>
        <translation>字体大小</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="275"/>
        <source>Frame width</source>
        <translation>边框宽度</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="417"/>
        <source>Report Title</source>
        <translation>报表标题</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="423"/>
        <source>Report Summary</source>
        <translation>报表摘要</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>Page Header</source>
        <translation>页眉</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="435"/>
        <source>Page Footer</source>
        <translation>页脚</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="441"/>
        <source>Master Data</source>
        <translation>主数据</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="447"/>
        <source>Data Grouping Header</source>
        <translation>数据组题头</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="454"/>
        <source>Data Grouping Footer</source>
        <translation>数据组脚注</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="461"/>
        <location filename="../mainwindow.cpp" line="2515"/>
        <source>Master Header</source>
        <translation>主数据题头</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="467"/>
        <location filename="../mainwindow.cpp" line="2511"/>
        <source>Master Footer</source>
        <translation>主数据脚注</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Line</source>
        <translation>直线</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Line with arrow at the end</source>
        <translatorcomment>头部箭头线</translatorcomment>
        <translation>尾部箭头线</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="511"/>
        <source>Line with arrow at the start</source>
        <translation>头部箭头线</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="517"/>
        <source>Line with arrows at both side</source>
        <translation>双箭头线</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="523"/>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="529"/>
        <source>Rounded rectangle</source>
        <translation>圆角矩形</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="535"/>
        <source>Ellipse</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="541"/>
        <source>Triangle</source>
        <translation>三角形</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="547"/>
        <source>Rhombus</source>
        <translation>菱形</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="646"/>
        <source>&amp;%1 %2</source>
        <translation>&amp;%1 %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="803"/>
        <location filename="../mainwindow.cpp" line="1054"/>
        <source>Page %1</source>
        <translation>第 %1 页</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <location filename="../mainwindow.cpp" line="995"/>
        <location filename="../mainwindow.cpp" line="1830"/>
        <location filename="../mainwindow.cpp" line="2643"/>
        <source>Saving</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <location filename="../mainwindow.cpp" line="995"/>
        <location filename="../mainwindow.cpp" line="1830"/>
        <location filename="../mainwindow.cpp" line="2643"/>
        <source>The report was changed.
Save the report?</source>
        <translation>报表已经修改.
是否保存报表?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1010"/>
        <source>Select File</source>
        <translation>选择文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1338"/>
        <source>Going to make undo: </source>
        <translation>马上执行撤销：</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1346"/>
        <source>Going to make redo: </source>
        <translation>马上执行恢复：</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1528"/>
        <source>Save File</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1528"/>
        <source>XML Files (*.xml)</source>
        <translation>XML 文件 (*.xml)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1542"/>
        <location filename="../mainwindow.cpp" line="2788"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1757"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1765"/>
        <source>Frame</source>
        <translation>边框</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2118"/>
        <source>Aligment hor</source>
        <translation>水平对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2122"/>
        <location filename="../mainwindow.cpp" line="2182"/>
        <location filename="../mainwindow.cpp" line="2211"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2127"/>
        <location filename="../mainwindow.cpp" line="2155"/>
        <source>Center</source>
        <translation>居中</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2132"/>
        <location filename="../mainwindow.cpp" line="2221"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2146"/>
        <source>Aligment ver</source>
        <translation>垂直对齐</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2150"/>
        <location filename="../mainwindow.cpp" line="2195"/>
        <location filename="../mainwindow.cpp" line="2231"/>
        <source>Top</source>
        <translation>顶部</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2160"/>
        <location filename="../mainwindow.cpp" line="2241"/>
        <source>Bottom</source>
        <translation>底部</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2169"/>
        <source>Height</source>
        <translation>高度</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2176"/>
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2189"/>
        <source>Length</source>
        <translation>长度</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2265"/>
        <source>FrameWidth</source>
        <translation>边框宽度</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2285"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2334"/>
        <source>Printing</source>
        <translation>打印</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2340"/>
        <source>Start New Numeration</source>
        <translation>新的计算</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2346"/>
        <source>Show In Group</source>
        <translation>在组中显示</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2352"/>
        <source>Start New Page</source>
        <translation>开始新的页面</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2358"/>
        <source>AutoHeight</source>
        <translation>自动调整高度</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>IgnoreRatioAspect</source>
        <translation>忽略缩放比例</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2370"/>
        <source>ArrowStart</source>
        <translation>头部箭头</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2376"/>
        <source>ArrowEnd</source>
        <translation>尾部箭头</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2382"/>
        <source>TextWrap</source>
        <translation>文本折行</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2388"/>
        <source>BackgroundColor</source>
        <translation>背景颜色</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2394"/>
        <source>BorderColor</source>
        <translation>边框颜色</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2403"/>
        <source>FontColor</source>
        <translation>字体颜色</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2409"/>
        <source>BarcodeType</source>
        <translation>条形码类型</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2415"/>
        <source>BarcodeFrameType</source>
        <translation>条形码表框样式</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2491"/>
        <source>Report title</source>
        <translation>报表标题</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2495"/>
        <source>Report summary</source>
        <translation>报表摘要</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2499"/>
        <source>Page header</source>
        <translation>页眉</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2503"/>
        <source>Page footer</source>
        <translation>页脚</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2507"/>
        <source>Master data</source>
        <translation>主数据</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2519"/>
        <source>Data Group Header</source>
        <translation>数据组标题</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2523"/>
        <source>Data Group Footer</source>
        <translation>数据组脚注</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2788"/>
        <source>This object %1 can&apos;t be a parent for %2</source>
        <translation>本对象 %1 不能最为 %2 的父对象</translation>
    </message>
</context>
<context>
    <name>PageSettingDlg</name>
    <message>
        <location filename="../PageSettingDlg.ui" line="32"/>
        <source>Page settings</source>
        <translation>页面设置</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="42"/>
        <source>Size</source>
        <translation>尺寸</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="51"/>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="56"/>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="61"/>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="66"/>
        <source>Letter</source>
        <translation>Letter</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="74"/>
        <source>Width</source>
        <translation>宽度</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="84"/>
        <location filename="../PageSettingDlg.ui" line="101"/>
        <location filename="../PageSettingDlg.ui" line="189"/>
        <location filename="../PageSettingDlg.ui" line="209"/>
        <location filename="../PageSettingDlg.ui" line="243"/>
        <location filename="../PageSettingDlg.ui" line="250"/>
        <source>cm</source>
        <translation>厘米</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="91"/>
        <source>Height</source>
        <translation>高度</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="138"/>
        <source>Orientation</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="146"/>
        <source>Portrait</source>
        <translation>纵向</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="166"/>
        <source>Landscape</source>
        <translation>横向</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="178"/>
        <source>Margins</source>
        <translation>边距</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="216"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="223"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="257"/>
        <source>Top</source>
        <translation>上</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="272"/>
        <source>Page border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="236"/>
        <source>Bottom</source>
        <translation>下</translation>
    </message>
    <message>
        <source>Page&apos;s border</source>
        <translation type="vanished">页面边框</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="280"/>
        <source>Draw border</source>
        <translation>绘制边框</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="287"/>
        <source>Border color</source>
        <translation>边框颜色</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="310"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="317"/>
        <source>Border width</source>
        <translation>边框宽度</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="327"/>
        <source>Border style</source>
        <translation>边框样式</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="364"/>
        <source>OK</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="371"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="57"/>
        <source>Cm</source>
        <translation>厘米</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="60"/>
        <source>Inch</source>
        <translation>英寸</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="29"/>
        <source>QtRptDesigner</source>
        <translation>QtRptDesigner</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../UndoCommands.cpp" line="44"/>
        <source>Changing Container&apos;s geometry</source>
        <translation>改变容器尺寸</translation>
    </message>
    <message>
        <location filename="../UndoCommands.cpp" line="102"/>
        <source>Adding Container</source>
        <translation>添加容器</translation>
    </message>
    <message>
        <location filename="../UndoCommands.cpp" line="167"/>
        <source>Deleting Container</source>
        <translation>删除容器</translation>
    </message>
    <message>
        <location filename="../UndoCommands.cpp" line="209"/>
        <source>Changing Container&apos;s parameters</source>
        <translation>删除容器</translation>
    </message>
    <message>
        <source>C-Total</source>
        <translation type="obsolete">列-总计</translation>
    </message>
    <message>
        <source>R-Total</source>
        <translation type="obsolete">行-总计</translation>
    </message>
    <message>
        <location filename="../../QtRPT/RptCrossTabObject.cpp" line="38"/>
        <source>Total</source>
        <translation type="unfinished">总计</translation>
    </message>
</context>
<context>
    <name>QTextEditEx</name>
    <message>
        <source>Cut</source>
        <translation type="vanished">剪切</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="vanished">...</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">复制</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">粘贴</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="vanished">加粗</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="vanished">斜体</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="vanished">下划线</translation>
    </message>
    <message>
        <source>Align left</source>
        <translation type="vanished">左对齐</translation>
    </message>
    <message>
        <source>Align center</source>
        <translation type="vanished">居中</translation>
    </message>
    <message>
        <source>Align right</source>
        <translation type="vanished">右对齐</translation>
    </message>
    <message>
        <source>Align jusify</source>
        <translation type="vanished">两端对齐</translation>
    </message>
    <message>
        <source>List</source>
        <translation type="vanished">列表</translation>
    </message>
    <message>
        <source>Font color</source>
        <translation type="vanished">字体颜色</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">字体</translation>
    </message>
    <message>
        <source>Font size</source>
        <translation type="vanished">字体大小</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation type="vanished">标准</translation>
    </message>
    <message>
        <source>Bullet List (Disc)</source>
        <translation type="vanished">符号列表(原点)</translation>
    </message>
    <message>
        <source>Bullet List (Circle)</source>
        <translation type="vanished">符号列表(圆形)</translation>
    </message>
    <message>
        <source>Bullet List (Square)</source>
        <translation type="vanished">符号列表(方形)</translation>
    </message>
    <message>
        <source>Ordered List (Decimal)</source>
        <translation type="vanished">有序列表(数字)</translation>
    </message>
    <message>
        <source>Ordered List (Alpha lower)</source>
        <translation type="vanished">有序列表(小写字母)</translation>
    </message>
    <message>
        <source>Ordered List (Alpha upper)</source>
        <translation type="vanished">有序列表(大写字母)</translation>
    </message>
</context>
<context>
    <name>QtRPT</name>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1517"/>
        <source>Save as PDF</source>
        <translation>另存为 PDF</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1522"/>
        <source>Save as HTML</source>
        <translation>另存为 HTML</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1528"/>
        <source>Save as XLSX</source>
        <translation>另存为 XLSX</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1549"/>
        <location filename="../../QtRPT/qtrpt.cpp" line="1554"/>
        <location filename="../../QtRPT/qtrpt.cpp" line="1559"/>
        <source>Save File</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1549"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF 文件 (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1554"/>
        <source>HTML Files (*.html)</source>
        <translation>HTML 文件 (*.html)</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1559"/>
        <source>XLSX Files (*.xlsx)</source>
        <translation>XLSX 文件 (*.xlsx)</translation>
    </message>
</context>
<context>
    <name>ReportBand</name>
    <message>
        <location filename="../ReportBand.cpp" line="65"/>
        <source>Report title</source>
        <translation>报表标题</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="71"/>
        <source>Report summary</source>
        <translation>报表摘要</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="77"/>
        <source>Page header</source>
        <translation>页眉</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="83"/>
        <source>Page footer</source>
        <translation>页脚</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="89"/>
        <source>Master band</source>
        <translation>主数据区</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="96"/>
        <source>Master footer</source>
        <translation>主数据题头</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="102"/>
        <source>Master header</source>
        <translation>主数据脚注</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="108"/>
        <source>Data Group Header</source>
        <translation>数据组题头</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="114"/>
        <source>Data Group Footer</source>
        <translation>数据组脚注</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="133"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
</context>
<context>
    <name>SettingDlg</name>
    <message>
        <location filename="../SettingDlg.ui" line="14"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="24"/>
        <source>Grid</source>
        <translation>网格</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="32"/>
        <source>Measurement&apos;s unit</source>
        <translation>测量单位</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="42"/>
        <source>Cm</source>
        <translation>厘米</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="55"/>
        <source>Inch</source>
        <translation>英寸</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="66"/>
        <source>Grid&apos;s step</source>
        <translation>最小网格</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="85"/>
        <source>Show grid</source>
        <translation>显示网格</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="95"/>
        <source>Internationalization</source>
        <translation>国际化</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="103"/>
        <source>Language:</source>
        <translation>语言:</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="111"/>
        <source>System Default</source>
        <translation>系统默认</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="116"/>
        <source>Arabic عربي</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="121"/>
        <source>American English</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="126"/>
        <source>Chinese</source>
        <translation>中文</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="131"/>
        <source>Dutch</source>
        <translation>荷兰语</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="136"/>
        <source>French</source>
        <translation>法语</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="141"/>
        <source>Georgian ქართული</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="146"/>
        <source>German</source>
        <translation>德语</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="151"/>
        <source>Portuguese</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="156"/>
        <source>Russian Русский</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="161"/>
        <source>Serbian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="166"/>
        <source>Serbian Latin</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="171"/>
        <source>Spanish</source>
        <translation>西班牙语</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="176"/>
        <source>Ukraine Український</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="189"/>
        <source>Check updates during start application</source>
        <translation>启动程序时检查更新</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="211"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="218"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="149"/>
        <source>Message QtRptDesigner</source>
        <translation>QtRptDesigner 信息</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="149"/>
        <source>The language for this application has been changed.
The change will take effect the next time the application is started.
Restart application?</source>
        <translation>程序语言已经变更.
变更将会在程序重启后生效.
重启程序?</translation>
    </message>
</context>
<context>
    <name>SqlDesigner</name>
    <message>
        <location filename="../SqlDesigner.ui" line="34"/>
        <source>Custom DS</source>
        <translation>自定义数据源</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="44"/>
        <source>SQL DS</source>
        <translation>SQL 数据源</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="88"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="105"/>
        <source>Connection&apos;s parameters</source>
        <translation>连接参数</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="182"/>
        <source>Host name</source>
        <translation>主 机 名</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="121"/>
        <location filename="../SqlDesigner.ui" line="189"/>
        <source>UTF8</source>
        <translation>UTF8</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="114"/>
        <source>Driver</source>
        <translation>驱    动</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="154"/>
        <source>Check</source>
        <translation>测试</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="175"/>
        <source>Connection coding</source>
        <translation>连接编码</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="161"/>
        <source>Connection</source>
        <translation>连    接</translation>
    </message>
    <message>
        <source>QSQLITE</source>
        <translation type="vanished">QSQLITE</translation>
    </message>
    <message>
        <source>QMYSQL</source>
        <translation type="vanished">QMYSQL</translation>
    </message>
    <message>
        <source>QMYSQL3</source>
        <translation type="vanished">QMYSQL3</translation>
    </message>
    <message>
        <source>QODBC</source>
        <translation type="vanished">QODBC</translation>
    </message>
    <message>
        <source>QODBC3</source>
        <translation type="vanished">QODBC3</translation>
    </message>
    <message>
        <source>QPSQL</source>
        <translation type="vanished">QPSQL</translation>
    </message>
    <message>
        <source>QPSQL7</source>
        <translation type="vanished">QPSQL7</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="134"/>
        <source>Charset coding</source>
        <translation>字符编码</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="51"/>
        <source>XML DS</source>
        <translation>XML 数据源</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="144"/>
        <source>Password</source>
        <translation>密    码</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="168"/>
        <source>User name</source>
        <translation>用 户 名</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="196"/>
        <source>DB name</source>
        <translation>数据库名</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="203"/>
        <source>Connection name</source>
        <translation>连 接 名</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="210"/>
        <source>Port</source>
        <translation>端    口</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="288"/>
        <source>SQL query</source>
        <translation>SQL 查询语句</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="324"/>
        <source>Select XML</source>
        <translation>选择 XML</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="388"/>
        <source>Field name</source>
        <translation>字段名</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="393"/>
        <source>Description</source>
        <translation>说明</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="404"/>
        <source>Preview data</source>
        <translation>预览数据</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="441"/>
        <location filename="../SqlDesigner.ui" line="444"/>
        <source>Clear diagram</source>
        <translation>清楚图表</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="459"/>
        <location filename="../SqlDesigner.ui" line="462"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="471"/>
        <location filename="../SqlDesigner.ui" line="474"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="477"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="486"/>
        <location filename="../SqlDesigner.ui" line="489"/>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="492"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="504"/>
        <location filename="../SqlDesigner.ui" line="507"/>
        <source>Add relationship</source>
        <translation>添加关系</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="516"/>
        <location filename="../SqlDesigner.ui" line="519"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="522"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="114"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="117"/>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="117"/>
        <source>Connected</source>
        <translation>已连接成功</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="161"/>
        <source>Select File</source>
        <translation>选择文件</translation>
    </message>
</context>
<context>
    <name>TContainerField</name>
    <message>
        <location filename="../TContainerField.cpp" line="28"/>
        <source>New Label</source>
        <translation>新建标签</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="73"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="77"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="84"/>
        <source>Move forward</source>
        <translation>前进</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="90"/>
        <source>Move back</source>
        <translation>后退</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="284"/>
        <source>New image</source>
        <translation>新建图像</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="291"/>
        <source>New diagram</source>
        <translation>新建图表</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="675"/>
        <location filename="../TContainerField.cpp" line="696"/>
        <source>Total</source>
        <translation type="unfinished">总计</translation>
    </message>
</context>
<context>
    <name>TContainerLine</name>
    <message>
        <location filename="../TContainerLine.cpp" line="243"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
</context>
<context>
    <name>UpdateDlg</name>
    <message>
        <source>Updating</source>
        <translation type="vanished">更新中</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="vanished">进度</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">更新</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation type="vanished">打开目录</translation>
    </message>
    <message>
        <source>Downloading %0. ..</source>
        <translation type="vanished">下载中 %0. ..</translation>
    </message>
</context>
<context>
    <name>XYZTextEditor</name>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="43"/>
        <source>Cut</source>
        <translation>剪切</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="46"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="63"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="80"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="113"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="133"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="153"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="189"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="209"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="229"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="249"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="308"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="60"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="77"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="110"/>
        <source>Bold</source>
        <translation>加粗</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="130"/>
        <source>Italic</source>
        <translation>斜体</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="150"/>
        <source>Underline</source>
        <translation>下划线</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="186"/>
        <source>Align left</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="206"/>
        <source>Align center</source>
        <translation>居中</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="226"/>
        <source>Align right</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="246"/>
        <source>Align jusify</source>
        <translation>两端对齐</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="282"/>
        <source>List</source>
        <translation>列表</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="305"/>
        <source>Font color</source>
        <translation>字体颜色</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="322"/>
        <source>Font</source>
        <translation>字体</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="332"/>
        <source>Font size</source>
        <translation>字体大小</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="438"/>
        <source>TextDirection</source>
        <translation>文本方向</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="441"/>
        <source>&lt;-</source>
        <translation>&lt;-</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="93"/>
        <source>Standard</source>
        <translation>标准</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="94"/>
        <source>Bullet List (Disc)</source>
        <translation>符号列表(原点)</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="95"/>
        <source>Bullet List (Circle)</source>
        <translation>符号列表(圆形)</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="96"/>
        <source>Bullet List (Square)</source>
        <translation>符号列表(方形)</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="97"/>
        <source>Ordered List (Decimal)</source>
        <translation>有序列表(数字)</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="98"/>
        <source>Ordered List (Alpha lower)</source>
        <translation>有序列表(小写字母)</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="99"/>
        <source>Ordered List (Alpha upper)</source>
        <translation>有序列表(大写字母)</translation>
    </message>
</context>
<context>
    <name>XYZUpdateDlg</name>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="14"/>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="38"/>
        <source>Updating</source>
        <translation>更新中</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="33"/>
        <source>Progress</source>
        <translation>进度</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="82"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="89"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.cpp" line="51"/>
        <source>Open Directory</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.cpp" line="74"/>
        <source>Downloading %0. ..</source>
        <translation>下载中 %0. ..</translation>
    </message>
</context>
</TS>
