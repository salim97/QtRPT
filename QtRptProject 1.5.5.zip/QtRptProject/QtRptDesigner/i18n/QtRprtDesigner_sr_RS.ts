<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sr_RS">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../aboutDlg.cpp" line="27"/>
        <source>About QtRptDesigner</source>
        <translation>О Програму QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="44"/>
        <source>Version: </source>
        <translation>Верзија: </translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="45"/>
        <source>Programmer: Aleksey Osipov</source>
        <translation>Програмер Aleksey Osipov</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="49"/>
        <source>2012-2015 years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="50"/>
        <source>Thanks for donation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="52"/>
        <source>Sailendram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="54"/>
        <source>Thanks for project developing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="56"/>
        <source>Lukas Lalinsky for DBmodel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="57"/>
        <source>Norbert Schlia for help in developing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="58"/>
        <source>Muhamad Bashir Al-Noimi for Arabic translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="59"/>
        <source>Luis Brochado for Portuguese translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="60"/>
        <source>Li Wei for Chinese translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="61"/>
        <source>Laurent Guilbert for French translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="62"/>
        <source>David Heremans for Dutch translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="63"/>
        <source>Mirko Marx for German translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="64"/>
        <source>Manuel Soriano for Spanish translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditFldDlg</name>
    <message>
        <location filename="../EditFldDlg.ui" line="14"/>
        <source>Field editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="61"/>
        <location filename="../EditFldDlg.ui" line="176"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="100"/>
        <source>Add variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="103"/>
        <location filename="../EditFldDlg.ui" line="123"/>
        <location filename="../EditFldDlg.ui" line="143"/>
        <location filename="../EditFldDlg.ui" line="466"/>
        <location filename="../EditFldDlg.ui" line="483"/>
        <location filename="../EditFldDlg.ui" line="714"/>
        <location filename="../EditFldDlg.ui" line="728"/>
        <location filename="../EditFldDlg.ui" line="742"/>
        <location filename="../EditFldDlg.ui" line="756"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="120"/>
        <source>Add function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="140"/>
        <source>Add formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="160"/>
        <source>Text direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="163"/>
        <source>&lt;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="227"/>
        <source>Condtion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="235"/>
        <source>Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="248"/>
        <source>Hightlighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="260"/>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="277"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="283"/>
        <source>Bold</source>
        <translation type="unfinished">Подебљано</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="290"/>
        <source>Italic</source>
        <translation type="unfinished">Курзив</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="297"/>
        <source>Underline</source>
        <translation type="unfinished">Подвучено</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="304"/>
        <source>Strikeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="339"/>
        <location filename="../EditFldDlg.ui" line="405"/>
        <source>Color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="354"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="360"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="370"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="480"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="497"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="599"/>
        <source>Diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="619"/>
        <source>Show caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="626"/>
        <source>Show grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="633"/>
        <source>Show legend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="640"/>
        <source>Set the params of the graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="663"/>
        <source>Real values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="673"/>
        <source>Percent values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="700"/>
        <source>Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="711"/>
        <source>Add row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="725"/>
        <source>Remove row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="739"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="753"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="807"/>
        <source>Caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="812"/>
        <source>Value</source>
        <translation type="unfinished">Вредност</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="817"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="833"/>
        <source>Barcode type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="857"/>
        <source>Frame type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="845"/>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="183"/>
        <source>Process as image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="190"/>
        <source>Image from database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="219"/>
        <source>Attention! You may enter just ONE variable and not any text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="593"/>
        <source>Diagram property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="607"/>
        <source>Chart caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="647"/>
        <source>Show graph caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="657"/>
        <source>Graph caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="877"/>
        <source>Height</source>
        <translation type="unfinished">Висина</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="884"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="935"/>
        <source>Dimensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="941"/>
        <source>Rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="951"/>
        <source>Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="964"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="970"/>
        <source>Show row header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="977"/>
        <source>Show column header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="984"/>
        <source>Show row total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="991"/>
        <source>Show column total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1003"/>
        <source>Row headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1023"/>
        <source>Row header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1035"/>
        <source>Column headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1055"/>
        <source>Column header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1084"/>
        <source>OK</source>
        <translation>У Реду</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1091"/>
        <source>Cancel</source>
        <translation>Одустани</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="234"/>
        <location filename="../EditFldDlg.cpp" line="294"/>
        <source>Empty line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="234"/>
        <location filename="../EditFldDlg.cpp" line="294"/>
        <source>The field contains empty line at the end.
Remove it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="575"/>
        <source>Save Image As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="577"/>
        <source>Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorDelegate</name>
    <message>
        <location filename="../mainwindow.cpp" line="52"/>
        <source>Left</source>
        <translation type="unfinished">Лево</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="53"/>
        <location filename="../mainwindow.cpp" line="63"/>
        <source>Center</source>
        <translation type="unfinished">Центар</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="54"/>
        <source>Right</source>
        <translation type="unfinished">Десно</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="55"/>
        <source>Justify</source>
        <translation type="unfinished">Центрирано</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="62"/>
        <source>Top</source>
        <translation type="unfinished">Горе</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="64"/>
        <source>Bottom</source>
        <translation type="unfinished">Доле</translation>
    </message>
</context>
<context>
    <name>FldPropertyDlg</name>
    <message>
        <location filename="../FldPropertyDlg.ui" line="14"/>
        <source>Expression editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="66"/>
        <source>Data filed grouping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="78"/>
        <source>Start line numeration for each group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="88"/>
        <source>Start new page for each group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="114"/>
        <source>Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="121"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="132"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="146"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="167"/>
        <source>Precision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="198"/>
        <source>Format string</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="212"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="243"/>
        <source>OK</source>
        <translation type="unfinished">У Реду</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="250"/>
        <source>Cancel</source>
        <translation type="unfinished">Одустани</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="54"/>
        <location filename="../FldPropertyDlg.cpp" line="93"/>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="55"/>
        <source>System variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="97"/>
        <location filename="../FldPropertyDlg.cpp" line="219"/>
        <source>Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="100"/>
        <source>Aggregate functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="135"/>
        <source>Text functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="141"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="148"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="155"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="162"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="169"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="176"/>
        <source>French(BE)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="183"/>
        <source>French(CH)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="191"/>
        <source>Math functions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ItemPropertyDlg</name>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="14"/>
        <source>Object property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="44"/>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="78"/>
        <source>Name</source>
        <translation type="unfinished">Име</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="105"/>
        <source>Relation property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="128"/>
        <source>Parent table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="145"/>
        <source>Columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="159"/>
        <source>reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="166"/>
        <source>Child table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="208"/>
        <source>OK</source>
        <translation type="unfinished">У Реду</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="215"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>QtRPT Designer</source>
        <translation>QtRPT Designer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <location filename="../mainwindow.cpp" line="2112"/>
        <location filename="../mainwindow.cpp" line="2275"/>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="157"/>
        <source>Value</source>
        <translation>Вредност</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>File</source>
        <translation>Датотека</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="195"/>
        <location filename="../mainwindow.cpp" line="307"/>
        <source>Report</source>
        <translation>Извештај</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Edit</source>
        <translation>Уређивање</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Help</source>
        <translation>Помоћ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="275"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="220"/>
        <source>Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="313"/>
        <source>toolBar_2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="324"/>
        <source>toolBar_3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="346"/>
        <location filename="../mainwindow.ui" line="349"/>
        <source>Exit</source>
        <translation>Излаз</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="358"/>
        <source>Page settings</source>
        <translation>Подешавање стране</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="370"/>
        <location filename="../mainwindow.ui" line="373"/>
        <source>Select tool</source>
        <translation>Алат за селекцију</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="385"/>
        <location filename="../mainwindow.ui" line="388"/>
        <source>Align left</source>
        <translation>Поравнај лево</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="400"/>
        <location filename="../mainwindow.ui" line="403"/>
        <source>Align center</source>
        <translation>Поравнај центар</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="415"/>
        <location filename="../mainwindow.ui" line="418"/>
        <source>Align right</source>
        <translation>Поравнај десно</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="430"/>
        <location filename="../mainwindow.ui" line="433"/>
        <location filename="../mainwindow.cpp" line="2137"/>
        <source>Justify</source>
        <translation>Центрирано</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="445"/>
        <location filename="../mainwindow.ui" line="448"/>
        <location filename="../mainwindow.cpp" line="2297"/>
        <source>Bold</source>
        <translation>Подебљано</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="460"/>
        <location filename="../mainwindow.ui" line="463"/>
        <location filename="../mainwindow.cpp" line="2307"/>
        <source>Italic</source>
        <translation>Курзив</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="475"/>
        <location filename="../mainwindow.ui" line="478"/>
        <location filename="../mainwindow.cpp" line="2317"/>
        <source>Underline</source>
        <translation>Подвучено</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="490"/>
        <location filename="../mainwindow.ui" line="493"/>
        <source>Top line</source>
        <translation>Горња линија</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="505"/>
        <location filename="../mainwindow.ui" line="508"/>
        <source>Bottom line</source>
        <translation>Доња линија</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="520"/>
        <location filename="../mainwindow.ui" line="523"/>
        <source>Left line</source>
        <translation>Лева линија</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="535"/>
        <location filename="../mainwindow.ui" line="538"/>
        <source>Right line</source>
        <translation>Десна линија</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="550"/>
        <location filename="../mainwindow.ui" line="553"/>
        <source>All frame line</source>
        <translation>Све линије</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="565"/>
        <location filename="../mainwindow.ui" line="568"/>
        <source>No frame</source>
        <translation>Без оквира</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="580"/>
        <location filename="../mainwindow.ui" line="583"/>
        <source>Insert band</source>
        <translation>Убаци групу</translation>
    </message>
    <message>
        <source>Add filed</source>
        <translation type="obsolete">Dodaj polje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="598"/>
        <source>Add Fleld</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="601"/>
        <source>Add field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="610"/>
        <location filename="../mainwindow.ui" line="613"/>
        <source>New report</source>
        <translation>Нов извештај</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="622"/>
        <location filename="../mainwindow.ui" line="625"/>
        <source>Open report</source>
        <translation>Отвори извештај</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="628"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="640"/>
        <location filename="../mainwindow.ui" line="643"/>
        <source>Save report</source>
        <translation>Сними извештај</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="646"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="658"/>
        <location filename="../mainwindow.ui" line="661"/>
        <source>Align top</source>
        <translation>Поравнај горе</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="673"/>
        <location filename="../mainwindow.ui" line="676"/>
        <source>Align V center</source>
        <translation>Поравнај В центар</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="688"/>
        <location filename="../mainwindow.ui" line="691"/>
        <source>Align bottom</source>
        <translation>Поравнај доле</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="700"/>
        <location filename="../mainwindow.ui" line="703"/>
        <source>Copy</source>
        <translation>Копирај</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="706"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="715"/>
        <location filename="../mainwindow.ui" line="718"/>
        <source>Cut</source>
        <translation>Исеци</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="721"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="733"/>
        <location filename="../mainwindow.ui" line="736"/>
        <source>Paste</source>
        <translation>Убаци</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="739"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="748"/>
        <location filename="../mainwindow.ui" line="751"/>
        <source>Save as</source>
        <translation>Сними као</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="760"/>
        <location filename="../mainwindow.ui" line="763"/>
        <source>Font color</source>
        <translation>Боја фонта</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="772"/>
        <location filename="../mainwindow.ui" line="775"/>
        <source>Background color</source>
        <translation>Позадинска боја</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <location filename="../mainwindow.ui" line="787"/>
        <source>Border color</source>
        <translation>Боја ивице</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="796"/>
        <source>About QtRptDesigner</source>
        <translation>О Програму O Programu QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="808"/>
        <source>Show Grid</source>
        <translation>Прикажи мрежу</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="811"/>
        <source>Show/Hide grid</source>
        <translation>Прикажи/Сакриј мрежу</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="826"/>
        <source>Add picture</source>
        <translation>Додај слику</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="835"/>
        <location filename="../mainwindow.ui" line="838"/>
        <source>Frame style</source>
        <translation>Стил фрејма</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="847"/>
        <location filename="../mainwindow.ui" line="850"/>
        <source>New Report Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="859"/>
        <location filename="../mainwindow.ui" line="862"/>
        <source>Delete Report Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="871"/>
        <location filename="../mainwindow.ui" line="874"/>
        <source>Align Field Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="883"/>
        <location filename="../mainwindow.ui" line="886"/>
        <source>Align Field Middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="895"/>
        <location filename="../mainwindow.ui" line="898"/>
        <source>Align Field Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="907"/>
        <location filename="../mainwindow.ui" line="910"/>
        <source>Align Field Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="919"/>
        <location filename="../mainwindow.ui" line="922"/>
        <source>Align Field Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="931"/>
        <location filename="../mainwindow.ui" line="934"/>
        <source>Align Field Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="943"/>
        <location filename="../mainwindow.ui" line="946"/>
        <source>Field Same Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="955"/>
        <location filename="../mainwindow.ui" line="958"/>
        <source>Field Same Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="967"/>
        <location filename="../mainwindow.ui" line="970"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="982"/>
        <location filename="../mainwindow.ui" line="985"/>
        <source>Magnifying glass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="997"/>
        <location filename="../mainwindow.ui" line="1000"/>
        <location filename="../mainwindow.cpp" line="2327"/>
        <source>Strikeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1009"/>
        <location filename="../mainwindow.ui" line="1012"/>
        <source>Group property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1021"/>
        <location filename="../mainwindow.ui" line="1024"/>
        <source>Check updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1039"/>
        <location filename="../mainwindow.ui" line="1042"/>
        <source>Add Diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1057"/>
        <location filename="../mainwindow.ui" line="1060"/>
        <source>Add Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1072"/>
        <location filename="../mainwindow.ui" line="1075"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1087"/>
        <location filename="../mainwindow.ui" line="1090"/>
        <source>Data Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1102"/>
        <location filename="../mainwindow.ui" line="1105"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1108"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1120"/>
        <location filename="../mainwindow.ui" line="1123"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1126"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1141"/>
        <location filename="../mainwindow.ui" line="1144"/>
        <source>Add Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1153"/>
        <location filename="../mainwindow.ui" line="1156"/>
        <source>Readme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1171"/>
        <location filename="../mainwindow.ui" line="1174"/>
        <source>Add Rich Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1183"/>
        <location filename="../mainwindow.ui" line="1186"/>
        <source>To group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1195"/>
        <location filename="../mainwindow.ui" line="1198"/>
        <source>To ungroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1213"/>
        <location filename="../mainwindow.ui" line="1216"/>
        <source>Add CrossTab object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1231"/>
        <location filename="../mainwindow.ui" line="1234"/>
        <source>Add CrossTabBD object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="275"/>
        <source>Frame width</source>
        <translation>Ширина фрејма</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="417"/>
        <source>Report Title</source>
        <translation>Наслов извештаја</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="423"/>
        <source>Report Summary</source>
        <translation>Резиме извештаја</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>Page Header</source>
        <translation>Заглавље</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="435"/>
        <source>Page Footer</source>
        <translation>Фуснота</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="441"/>
        <source>Master Data</source>
        <translation>Главни Подаци</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="467"/>
        <location filename="../mainwindow.cpp" line="2511"/>
        <source>Master Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="461"/>
        <location filename="../mainwindow.cpp" line="2515"/>
        <source>Master Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="233"/>
        <source>Font name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="447"/>
        <source>Data Grouping Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="454"/>
        <source>Data Grouping Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="517"/>
        <source>Line with arrows at both side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="523"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="529"/>
        <source>Rounded rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="535"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="541"/>
        <source>Triangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="547"/>
        <source>Rhombus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="646"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="803"/>
        <location filename="../mainwindow.cpp" line="1054"/>
        <source>Page %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <location filename="../mainwindow.cpp" line="995"/>
        <location filename="../mainwindow.cpp" line="1830"/>
        <location filename="../mainwindow.cpp" line="2643"/>
        <source>Saving</source>
        <translation type="unfinished">Снимање</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="983"/>
        <location filename="../mainwindow.cpp" line="995"/>
        <location filename="../mainwindow.cpp" line="1830"/>
        <location filename="../mainwindow.cpp" line="2643"/>
        <source>The report was changed.
Save the report?</source>
        <translation type="unfinished">Извештај је измењен.
Сними извештај?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1010"/>
        <source>Select File</source>
        <translation type="unfinished">Изабери Датотеку</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1528"/>
        <source>Save File</source>
        <translation type="unfinished">Сними Датотеку</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1528"/>
        <source>XML Files (*.xml)</source>
        <translation type="unfinished">XML Датотеке (*.xml)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2118"/>
        <source>Aligment hor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2122"/>
        <location filename="../mainwindow.cpp" line="2182"/>
        <location filename="../mainwindow.cpp" line="2211"/>
        <source>Left</source>
        <translation type="unfinished">Лево</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2127"/>
        <location filename="../mainwindow.cpp" line="2155"/>
        <source>Center</source>
        <translation type="unfinished">Центар</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2132"/>
        <location filename="../mainwindow.cpp" line="2221"/>
        <source>Right</source>
        <translation type="unfinished">Десно</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Line with arrow at the end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="511"/>
        <source>Line with arrow at the start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1338"/>
        <source>Going to make undo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1346"/>
        <source>Going to make redo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1542"/>
        <location filename="../mainwindow.cpp" line="2788"/>
        <source>Error</source>
        <translation type="unfinished">Грешка</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1757"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1765"/>
        <source>Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2146"/>
        <source>Aligment ver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2150"/>
        <location filename="../mainwindow.cpp" line="2195"/>
        <location filename="../mainwindow.cpp" line="2231"/>
        <source>Top</source>
        <translation type="unfinished">Горе</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2160"/>
        <location filename="../mainwindow.cpp" line="2241"/>
        <source>Bottom</source>
        <translation type="unfinished">Доле</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2169"/>
        <source>Height</source>
        <translation type="unfinished">Висина</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2176"/>
        <source>Width</source>
        <translation type="unfinished">Ширина</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2189"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2265"/>
        <source>FrameWidth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2285"/>
        <source>Size</source>
        <translation type="unfinished">Величина</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2334"/>
        <source>Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2340"/>
        <source>Start New Numeration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2346"/>
        <source>Show In Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2352"/>
        <source>Start New Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2358"/>
        <source>AutoHeight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>IgnoreRatioAspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2370"/>
        <source>ArrowStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2376"/>
        <source>ArrowEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2382"/>
        <source>TextWrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2388"/>
        <source>BackgroundColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2394"/>
        <source>BorderColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2403"/>
        <source>FontColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2409"/>
        <source>BarcodeType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2415"/>
        <source>BarcodeFrameType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2491"/>
        <source>Report title</source>
        <translation type="unfinished">Наслов извештаја</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2495"/>
        <source>Report summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2499"/>
        <source>Page header</source>
        <translation type="unfinished">Заглавље</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2503"/>
        <source>Page footer</source>
        <translation type="unfinished">Фуснота</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2507"/>
        <source>Master data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2519"/>
        <source>Data Group Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2523"/>
        <source>Data Group Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2788"/>
        <source>This object %1 can&apos;t be a parent for %2</source>
        <translation type="unfinished">Објекат %1 не може бити родитељ објекту %2</translation>
    </message>
</context>
<context>
    <name>PageSettingDlg</name>
    <message>
        <location filename="../PageSettingDlg.ui" line="32"/>
        <source>Page settings</source>
        <translation>Подешавање странице</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="42"/>
        <source>Size</source>
        <translation>Величина</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="51"/>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="56"/>
        <source>A4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="61"/>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="66"/>
        <source>Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="74"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="84"/>
        <location filename="../PageSettingDlg.ui" line="101"/>
        <location filename="../PageSettingDlg.ui" line="189"/>
        <location filename="../PageSettingDlg.ui" line="209"/>
        <location filename="../PageSettingDlg.ui" line="243"/>
        <location filename="../PageSettingDlg.ui" line="250"/>
        <source>cm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="91"/>
        <source>Height</source>
        <translation>Висина</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="138"/>
        <source>Orientation</source>
        <translation>Оријентација</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="146"/>
        <source>Portrait</source>
        <translation>Усправно</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="166"/>
        <source>Landscape</source>
        <translation>Положено</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="178"/>
        <source>Margins</source>
        <translation>Маргине</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="216"/>
        <source>Left</source>
        <translation>Лево</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="223"/>
        <source>Right</source>
        <translation>Десно</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="257"/>
        <source>Top</source>
        <translation>Горе</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="272"/>
        <source>Page border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="236"/>
        <source>Bottom</source>
        <translation>Доле</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="280"/>
        <source>Draw border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="287"/>
        <source>Border color</source>
        <translation type="unfinished">Боја ивице</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="310"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="317"/>
        <source>Border width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="327"/>
        <source>Border style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="364"/>
        <source>OK</source>
        <translation>У Реду</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="371"/>
        <source>Cancel</source>
        <translation>Одустани</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="57"/>
        <source>Cm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="60"/>
        <source>Inch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="29"/>
        <source>QtRptDesigner</source>
        <translation>QtRptDesigner</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../UndoCommands.cpp" line="44"/>
        <source>Changing Container&apos;s geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UndoCommands.cpp" line="102"/>
        <source>Adding Container</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UndoCommands.cpp" line="167"/>
        <source>Deleting Container</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UndoCommands.cpp" line="209"/>
        <source>Changing Container&apos;s parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QtRPT/RptCrossTabObject.cpp" line="38"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTextEditEx</name>
    <message>
        <source>Cut</source>
        <translation type="obsolete">Исеци</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Копирај</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Убаци</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Подебљано</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Курзив</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="obsolete">Подвучено</translation>
    </message>
    <message>
        <source>Align left</source>
        <translation type="obsolete">Поравнај лево</translation>
    </message>
    <message>
        <source>Align center</source>
        <translation type="obsolete">Поравнај центар</translation>
    </message>
    <message>
        <source>Align right</source>
        <translation type="obsolete">Поравнај десно</translation>
    </message>
    <message>
        <source>Font color</source>
        <translation type="obsolete">Боја фонта</translation>
    </message>
</context>
<context>
    <name>QtRPT</name>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1517"/>
        <source>Save as PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1522"/>
        <source>Save as HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1528"/>
        <source>Save as XLSX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1549"/>
        <location filename="../../QtRPT/qtrpt.cpp" line="1554"/>
        <location filename="../../QtRPT/qtrpt.cpp" line="1559"/>
        <source>Save File</source>
        <translation type="unfinished">Сними Датотеку</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1549"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1554"/>
        <source>HTML Files (*.html)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1559"/>
        <source>XLSX Files (*.xlsx)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReportBand</name>
    <message>
        <location filename="../ReportBand.cpp" line="65"/>
        <source>Report title</source>
        <translation>Наслов извештаја</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="71"/>
        <source>Report summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="77"/>
        <source>Page header</source>
        <translation>Заглавље</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="83"/>
        <source>Page footer</source>
        <translation>Фуснота</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="89"/>
        <source>Master band</source>
        <translation>Главни Подаци</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="96"/>
        <source>Master footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="102"/>
        <source>Master header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="108"/>
        <source>Data Group Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="114"/>
        <source>Data Group Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="133"/>
        <source>Delete</source>
        <translation>Обриши</translation>
    </message>
</context>
<context>
    <name>SettingDlg</name>
    <message>
        <location filename="../SettingDlg.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="24"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="66"/>
        <source>Grid&apos;s step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="32"/>
        <source>Measurement&apos;s unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="42"/>
        <source>Cm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="55"/>
        <source>Inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="85"/>
        <source>Show grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="95"/>
        <source>Internationalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="103"/>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="111"/>
        <source>System Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="116"/>
        <source>Arabic عربي</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="121"/>
        <source>American English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="126"/>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="131"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="136"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="141"/>
        <source>Georgian ქართული</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="146"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="151"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="156"/>
        <source>Russian Русский</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="171"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="176"/>
        <source>Ukraine Український</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="161"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="166"/>
        <source>Serbian Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="189"/>
        <source>Check updates during start application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="211"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="218"/>
        <source>Cancel</source>
        <translation type="unfinished">Одустани</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="149"/>
        <source>Message QtRptDesigner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="149"/>
        <source>The language for this application has been changed.
The change will take effect the next time the application is started.
Restart application?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SqlDesigner</name>
    <message>
        <location filename="../SqlDesigner.ui" line="34"/>
        <source>Custom DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="44"/>
        <source>SQL DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="114"/>
        <source>Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="105"/>
        <source>Connection&apos;s parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="51"/>
        <source>XML DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="203"/>
        <source>Connection name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="210"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="324"/>
        <source>Select XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="388"/>
        <source>Field name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="393"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="404"/>
        <source>Preview data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="441"/>
        <location filename="../SqlDesigner.ui" line="444"/>
        <source>Clear diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="459"/>
        <location filename="../SqlDesigner.ui" line="462"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="471"/>
        <location filename="../SqlDesigner.ui" line="474"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="477"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="486"/>
        <location filename="../SqlDesigner.ui" line="489"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="492"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="504"/>
        <location filename="../SqlDesigner.ui" line="507"/>
        <source>Add relationship</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="516"/>
        <location filename="../SqlDesigner.ui" line="519"/>
        <source>Delete</source>
        <translation type="unfinished">Обриши</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="522"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="161"/>
        <source>Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="154"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="196"/>
        <source>DB name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="168"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="182"/>
        <source>Host name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="144"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="175"/>
        <source>Connection coding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="121"/>
        <location filename="../SqlDesigner.ui" line="189"/>
        <source>UTF8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="134"/>
        <source>Charset coding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="288"/>
        <source>SQL query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="88"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="114"/>
        <source>Error</source>
        <translation type="unfinished">Грешка</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="117"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="117"/>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="161"/>
        <source>Select File</source>
        <translation type="unfinished">Изабери Датотеку</translation>
    </message>
</context>
<context>
    <name>TContainerField</name>
    <message>
        <location filename="../TContainerField.cpp" line="28"/>
        <source>New Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="73"/>
        <source>Edit</source>
        <translation>Уређивање</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="77"/>
        <source>Delete</source>
        <translation>Обриши</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="84"/>
        <source>Move forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="90"/>
        <source>Move back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="284"/>
        <source>New image</source>
        <translation type="unfinished">Нова слика</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="291"/>
        <source>New diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="675"/>
        <location filename="../TContainerField.cpp" line="696"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TContainerLine</name>
    <message>
        <location filename="../TContainerLine.cpp" line="243"/>
        <source>Delete</source>
        <translation type="unfinished">Обриши</translation>
    </message>
</context>
<context>
    <name>UpdateDlg</name>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Одустани</translation>
    </message>
</context>
<context>
    <name>XYZTextEditor</name>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="43"/>
        <source>Cut</source>
        <translation type="unfinished">Исеци</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="46"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="63"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="80"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="113"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="133"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="153"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="189"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="209"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="229"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="249"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="308"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="60"/>
        <source>Copy</source>
        <translation type="unfinished">Копирај</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="77"/>
        <source>Paste</source>
        <translation type="unfinished">Убаци</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="110"/>
        <source>Bold</source>
        <translation type="unfinished">Подебљано</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="130"/>
        <source>Italic</source>
        <translation type="unfinished">Курзив</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="150"/>
        <source>Underline</source>
        <translation type="unfinished">Подвучено</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="186"/>
        <source>Align left</source>
        <translation type="unfinished">Поравнај лево</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="206"/>
        <source>Align center</source>
        <translation type="unfinished">Поравнај центар</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="226"/>
        <source>Align right</source>
        <translation type="unfinished">Поравнај десно</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="246"/>
        <source>Align jusify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="282"/>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="305"/>
        <source>Font color</source>
        <translation type="unfinished">Боја фонта</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="322"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="332"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="438"/>
        <source>TextDirection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="441"/>
        <source>&lt;-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="93"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="94"/>
        <source>Bullet List (Disc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="95"/>
        <source>Bullet List (Circle)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="96"/>
        <source>Bullet List (Square)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="97"/>
        <source>Ordered List (Decimal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="98"/>
        <source>Ordered List (Alpha lower)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="99"/>
        <source>Ordered List (Alpha upper)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XYZUpdateDlg</name>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="14"/>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="38"/>
        <source>Updating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="33"/>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="82"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="89"/>
        <source>Cancel</source>
        <translation type="unfinished">Одустани</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.cpp" line="51"/>
        <source>Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.cpp" line="74"/>
        <source>Downloading %0. ..</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
